# blazedemo
Automation Scenarios:
----------------------------------
1. Able to lauch url and search flight-> Book flight with all details
2. Able to book without details?
3. Price shown across pages for a flight travel are same.
4. Home -> Login, Home ->Register
5. Home ->Forgot password
6. Check out link
7. Application access direct to confirmation link


API
-------------
SpaceX.postman_collection is attached in the project for API test scenarios.

package com.blaze.agency.demo.utils;

import org.testng.log4testng.Logger;

public class Log4JUtils {
	
	static Logger logger = Logger.getLogger(Log4JUtils.class);
	
	//Work in progress

}

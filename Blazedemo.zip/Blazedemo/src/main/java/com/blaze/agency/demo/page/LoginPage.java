package com.blaze.agency.demo.page;

import org.openqa.selenium.WebDriver;

public class LoginPage {
	
	WebDriver driver;
	
	public LoginPage() {
		this.driver = driver;
	}

	
}

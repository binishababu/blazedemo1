package com.blaze.agency.demo.page;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

import com.blaze.agency.demo.utils.TestUtils;

public class BookFlightPage {
	WebDriver driver;
	SoftAssert softAssert = new SoftAssert();
	
	
	public BookFlightPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH, using="//h2")
	WebElement txtHeader;
	
	@FindBy(how=How.XPATH, using="//form//div/input[@type='submit']")
	WebElement purchaseBtn;
	
	public void purchaseFlight(WebDriver driver) {
		
		try {
			TestUtils.waitForPageLoad(driver);
			TestUtils.focusAndClick(14);
//			purchaseBtn.click();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	public void removeNode() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JavascriptExecutor js = null;
		if (driver instanceof JavascriptExecutor) {
		    js = (JavascriptExecutor) driver;
		}
		js.executeScript("return document.getElementsByTagame('head')[0].remove();");

	}

}

package com.blaze.agency.demo.utils;

public  class TestConstants {
	
	public static final String FROM_CITY = "Paris";
	public static final String TO_CITY = "New York";
	public static final String HEADER = "Flights from ";
	public static final String TO = "Flights from ";
	public static final String CHOOSEFLIGHT = "Choose This Flight";
	public static final String CONFIRMATION_URL = "https://blazedemo.com/confirmation.php";

}

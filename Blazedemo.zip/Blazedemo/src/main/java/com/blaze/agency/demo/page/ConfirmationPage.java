package com.blaze.agency.demo.page;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

import com.blaze.agency.demo.utils.TestConstants;
import com.blaze.agency.demo.utils.TestUtils;

public class ConfirmationPage {
	
		
		WebDriver driver;
		SoftAssert softAssert = new SoftAssert();
						
			public ConfirmationPage(WebDriver driver) {
				PageFactory.initElements(driver, this);
			}
			
			@FindBy(how=How.XPATH, using="//h1")
			WebElement txtHeader;
			@CacheLookup
			
			@FindBy(how=How.XPATH, using="/html/body/div[2]/div/table/tbody/tr[1]/td[2]")
			WebElement confirmationId;
					
			
			public void getConfirmationId() {
				System.out.println(driver.getPageSource().toString());
				TestUtils.existsElement(driver, "/html/body");
				String text = driver.findElement(By.xpath("/html/body/div[2]/div/table/tbody/tr[1]/td[2]")).getText().toString();
				
				System.out.println("Text "+text);
			}
			
			public void getAllValues() {
				String pageSource=driver.findElement(By.tagName("html")).getText();
				System.out.println("Page Source "+pageSource);
				
//				driver.getPageSource().	
				
			}
			
			public void removeNode() {
				JavascriptExecutor js = null;
				if (driver instanceof JavascriptExecutor) {
				    js = (JavascriptExecutor) driver;
				}
				js.executeScript("return document.getElementsByTagame('head')[0].remove();");

			}
			
			
			public Boolean verifyControlInConfirmation(WebDriver driver) {
				TestUtils.waitForPageLoad(driver);
				Boolean isConfirmationPage = driver.getCurrentUrl().toString().equalsIgnoreCase(TestConstants.CONFIRMATION_URL);
				return isConfirmationPage;
					
				}
			
}

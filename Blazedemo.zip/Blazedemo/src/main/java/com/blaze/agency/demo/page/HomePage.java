package com.blaze.agency.demo.page;

public class HomePage {

}

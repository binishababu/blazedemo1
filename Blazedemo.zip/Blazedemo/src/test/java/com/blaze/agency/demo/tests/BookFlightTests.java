package com.blaze.agency.demo.tests;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.blaze.agency.demo.BaseWebDriver;
import com.blaze.agency.demo.page.BookFlightPage;
import com.blaze.agency.demo.page.ChooseFlightPage;
import com.blaze.agency.demo.page.ConfirmationPage;
import com.blaze.agency.demo.page.FindFlightsPage;
import com.blaze.agency.demo.utils.TestConstants;

public class BookFlightTests extends BaseWebDriver{
	
	SoftAssert softAssert = new SoftAssert();
	BookFlightPage bp = PageFactory.initElements(driver, BookFlightPage.class);
	
	/**
	 * Verify whether user is able to search for a flight without providing user details
	 * @throws InterruptedException 
	 */
	@Test(enabled=true)
	public void verifyBookFlightWithoutData() throws InterruptedException  {
		
		FindFlightsPage fp = new FindFlightsPage(driver);
		verifytTextPresent(driver, "Find Flights");
		
		System.out.println("Search for the flight.");
		fp.searchForFLight();
		
		
		System.out.println("verify Header in Choose flight page");
		ChooseFlightPage chooseFlight = new ChooseFlightPage(driver);
		chooseFlight.verifyHeader(TestConstants.FROM_CITY, TestConstants.TO_CITY);
		
		System.out.println("Select a flight");
		chooseFlight.chooseAFlight();
		
		System.out.println("Purchase Flight without adding any value");
		bp.purchaseFlight(driver);
		
		ConfirmationPage cp = PageFactory.initElements(driver, ConfirmationPage.class);
		softAssert.assertEquals(false, driver.getPageSource().contains("id"));
	}
	
	/**
	 * Verify successful booking with valid details.
	 */
	@Test(enabled=false)
    public void verifyBookFlightWithValidData() {
		
	}
	
	
	/**
	 * Verify correct price and correct flight details got booked
	 */
	@Test(enabled=false)
    public void verifyPriceAndFlightDetails() {
		
	}
	
	
	/**
	 * Verify on Registration of the application.
	 */
	@Test(enabled=false)
    public void verifyRegistration() {
		
	}
	
	/**
	 * Verify on Login to the application.
	 */
	@Test(enabled=false)
    public void verifyLoginToApplication() {
		
	}
}
